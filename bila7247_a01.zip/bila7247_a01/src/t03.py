"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Muhammad Bilal
ID:      169047247
Email:   bila7247@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""
# # Imports
#
# # Constants
#
# def func():
# """
# -------------------------------------------------------
# description
# Use:
# -------------------------------------------------------
# Parameters:
#     name - description (type)
# Returns:
#     name - description (type)
# ------------------------------------------------------
# """

lInM = input('What is length in miles')
float(lInM)
lInKm = (float(lInM)*1.61)
print('Length in km is ', lInKm)
